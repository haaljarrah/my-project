package tictactoe;


public abstract class Player {
    int score;
    int point;

    abstract int enterNum(String p,String o);
    public Player(int s, int p) {
        score = s;
        point = p;
    }

}
