package tictactoe;

import static tictactoe.BoardList.winner;

public class Game {
    static Player first;
    static Player second;
    static BoardList board;
    static int count;


    public Game(Player p1, Player p2) {
        board = new BoardList();
        first = p1;
        second = p2;
        count=0;
    }
     static void startGame() {
         while (winner == null) {
             if (count % 2 == 0)
                 board.enterNumber(first.enterNum("X", "O"), "X");
             else
                 board.enterNumber(second.enterNum("O", "X"), "O");
             count++;
         }
         if (winner.equalsIgnoreCase("draw")) {
             System.out.println(
                     "It's a draw! Thanks for playing.");
         }

         // For winner -to display Congratulations! message.
         else {
             System.out.println(
                     "Congratulations! " + winner
                             + "'s have won! Thanks for playing.");
         }


     }
}